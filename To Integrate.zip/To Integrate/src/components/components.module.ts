import { NgModule } from '@angular/core';
import { NavbarComponent } from './navbar/navbar';
@NgModule({
	declarations: [NavbarComponent],
	imports: [],
	exports: [NavbarComponent]
})
export class ComponentsModule {}
