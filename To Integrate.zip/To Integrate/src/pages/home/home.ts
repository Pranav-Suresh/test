import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
username:any;
  constructor(public navCtrl: NavController) {
    console.log("From home page",window.localStorage.getItem('username'));
    this.username=window.localStorage.getItem('username');
  }

}
